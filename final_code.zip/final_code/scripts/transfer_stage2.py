"""
Stage 2: few-shot transfer from the Madrid-trained Stage 1 model to Amsterdam,
using only `n` labeled Amsterdam pixels per class (n in {5, 25, 50, 100, 200}
per the submission requirements).

Three strategies, evaluated head-to-head:

1. `plain_prototype` - the Notebook 4 baseline: nearest-class-mean in the
   standardised Madrid feature space, using only the n Amsterdam examples.

2. `shrinkage_prototype` - the main improvement targeted at the "Best low-data
   F1" prize. At very small n, an Amsterdam class mean estimated from 5-25
   points is noisy and can be pulled off by a couple of unusual pixels. This
   blends the Amsterdam few-shot class mean with the corresponding Madrid
   class mean (an Empirical-Bayes-style shrinkage estimator):

       prototype_k = (n_k * mean_amsterdam_k + alpha * mean_madrid_k) / (n_k + alpha)

   `alpha` controls how strongly to trust the Madrid prior. As n_k grows, the
   Amsterdam-specific mean dominates automatically (n_k / (n_k + alpha) -> 1),
   so this strategy converges to plain nearest-prototype at large n while
   being much more stable at n=5-25. This directly encodes the challenge's
   framing (Notebook 1, sec 1.7): a good Stage 1 representation should make
   Madrid class means informative "priors" for Amsterdam, not just Madrid-only
   trivia.

3. `self_training` - uses the Stage 1 model's zero-shot predictions on the
   *unlabeled* remainder of Amsterdam as noisy pseudo-labels (keeping only
   high-confidence ones), pools them with the n true labels, and refits a
   shallow classifier. Helps most once n is large enough (>=50) that the true
   labels can anchor the pseudo-label quality; can hurt at n=5, so it is only
   one candidate among several rather than the sole strategy.

Run all three at every shot count and report mean +/- std over repeated random
draws; per the scoring rubric you can pick the winning strategy per shot count
or simply the single best-average strategy for a cleaner story in the writeup.

Usage:
    from scripts.transfer_stage2 import run_all_strategies
    results = run_all_strategies(
        X_madrid, y_madrid, X_amsterdam, y_amsterdam,
        shots=[5, 25, 50, 100, 200], n_trials=20,
    )
"""

from __future__ import annotations

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score

RANDOM_STATE = 42


def _class_prototypes(X: np.ndarray, y: np.ndarray) -> dict[int, np.ndarray]:
    return {c: X[y == c].mean(axis=0) for c in np.unique(y)}


def _predict_by_prototype(X_query: np.ndarray, prototypes: dict[int, np.ndarray]) -> np.ndarray:
    classes = sorted(prototypes)
    proto_mat = np.stack([prototypes[c] for c in classes])
    dists = np.linalg.norm(X_query[:, None, :] - proto_mat[None, :, :], axis=2)
    return np.array(classes)[dists.argmin(axis=1)]


def plain_prototype(X_support, y_support, X_query, **_):
    protos = _class_prototypes(X_support, y_support)
    return _predict_by_prototype(X_query, protos)


def shrinkage_prototype(X_support, y_support, X_query, madrid_prototypes=None, alpha=15.0, **_):
    if madrid_prototypes is None:
        raise ValueError("shrinkage_prototype requires madrid_prototypes")
    amsterdam_protos = _class_prototypes(X_support, y_support)
    blended = {}
    for c, m_proto in madrid_prototypes.items():
        if c in amsterdam_protos:
            n_k = (y_support == c).sum()
            blended[c] = (n_k * amsterdam_protos[c] + alpha * m_proto) / (n_k + alpha)
        else:
            blended[c] = m_proto
    return _predict_by_prototype(X_query, blended)


def self_training(
    X_support, y_support, X_query, stage1_model=None,
    confidence_threshold=0.7, max_pseudo_per_class=300,
    precomputed_proba=None, precomputed_classes=None, **_,
):
    """
    precomputed_proba / precomputed_classes: optional - if the caller already
    ran stage1_model.predict_proba() once on the *full* target-domain pool
    (before any support/query split), pass the matching rows here to skip
    re-running inference every trial. On real-scale data (tens of thousands
    of query rows) this inference is the dominant cost of run_all_strategies,
    and it doesn't change across trials - only which rows count as "query"
    vs. "support" changes, not the model's prediction for a given row.
    """
    if precomputed_proba is not None:
        proba, classes = precomputed_proba, precomputed_classes
    else:
        if stage1_model is None:
            raise ValueError("self_training requires a fitted stage1_model (or precomputed_proba)")
        proba = stage1_model.predict_proba(X_query)
        classes = stage1_model.classes_
    conf = proba.max(axis=1)
    pseudo_labels = classes[proba.argmax(axis=1)]

    keep_idx = []
    for c in classes:
        c_idx = np.where((pseudo_labels == c) & (conf >= confidence_threshold))[0]
        if len(c_idx) > max_pseudo_per_class:
            # keep the most confident ones
            c_idx = c_idx[np.argsort(-conf[c_idx])[:max_pseudo_per_class]]
        keep_idx.extend(c_idx.tolist())

    if keep_idx:
        X_pseudo = X_query[keep_idx]
        y_pseudo = pseudo_labels[keep_idx]
        X_train = np.vstack([X_support, X_pseudo])
        y_train = np.concatenate([y_support, y_pseudo])
    else:
        X_train, y_train = X_support, y_support

    clf = RandomForestClassifier(
        n_estimators=200, max_depth=8, min_samples_leaf=3,
        class_weight="balanced", random_state=RANDOM_STATE, n_jobs=-1,
    )
    clf.fit(X_train, y_train)
    return clf.predict(X_query)


STRATEGIES = {
    "plain_prototype": plain_prototype,
    "shrinkage_prototype": shrinkage_prototype,
    "self_training": self_training,
}


def run_all_strategies(
    X_madrid, y_madrid, X_amsterdam, y_amsterdam,
    shots=(5, 25, 50, 100, 200), n_trials=20, stage1_model=None,
):
    """
    Returns {strategy_name: {n_shots: {"scores": [...], "mean": .., "std": ..}}}.
    A fresh RNG stream per (strategy, n_shots) keeps trials comparable across
    strategies while still varying the support set draw across trials.
    """
    madrid_protos = _class_prototypes(X_madrid, y_madrid)
    classes_ams = np.unique(y_amsterdam)
    results = {name: {} for name in STRATEGIES}

    # Run stage1_model inference on the full target-domain pool exactly once
    # (see self_training's docstring) instead of once per trial - on
    # real-scale data this is the dominant cost and is trial-invariant.
    full_proba, full_classes = None, None
    if stage1_model is not None:
        full_proba = stage1_model.predict_proba(X_amsterdam)
        full_classes = stage1_model.classes_

    for n_shots in shots:
        rng = np.random.default_rng(RANDOM_STATE + n_shots)
        trial_support_idx = []
        for _ in range(n_trials):
            support_idx = []
            for c in classes_ams:
                c_idx = np.where(y_amsterdam == c)[0]
                chosen = rng.choice(c_idx, min(n_shots, len(c_idx)), replace=False)
                support_idx.extend(chosen.tolist())
            trial_support_idx.append(np.array(support_idx))

        for name, fn in STRATEGIES.items():
            scores = []
            for support_idx in trial_support_idx:
                query_mask = np.ones(len(y_amsterdam), dtype=bool)
                query_mask[support_idx] = False
                X_sup, y_sup = X_amsterdam[support_idx], y_amsterdam[support_idx]
                X_qry, y_qry = X_amsterdam[query_mask], y_amsterdam[query_mask]

                extra = {}
                if name == "self_training" and full_proba is not None:
                    extra["precomputed_proba"] = full_proba[query_mask]
                    extra["precomputed_classes"] = full_classes

                pred = fn(
                    X_sup, y_sup, X_qry,
                    madrid_prototypes=madrid_protos,
                    stage1_model=stage1_model,
                    **extra,
                )
                scores.append(f1_score(y_qry, pred, average="macro", zero_division=0))

            results[name][n_shots] = {
                "scores": scores,
                "mean": float(np.mean(scores)),
                "std": float(np.std(scores)),
            }

    return results


def summarize_best_strategy(results: dict) -> dict:
    """Pick the strategy with the highest mean F1 averaged across all shot counts
    (targets the 'Best average F1' prize) and report its per-n numbers, which
    is what goes in the required results table and F1-vs-log2(n) plot."""
    avg_by_strategy = {
        name: np.mean([v["mean"] for v in per_n.values()]) for name, per_n in results.items()
    }
    best_name = max(avg_by_strategy, key=avg_by_strategy.get)
    return {"best_strategy": best_name, "per_n": results[best_name], "avg_f1": avg_by_strategy[best_name]}


if __name__ == "__main__":
    print(__doc__)
