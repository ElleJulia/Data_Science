import sys, time
import numpy as np
import pandas as pd

BASE_BANDS = ['Blue', 'Green', 'Red', 'NIR', 'SWIR1', 'SWIR2']
INDEX_COLS = ['NDVI', 'NDBI', 'UI', 'MNDWI', 'BSI']
PID = ['px_key', 'py_key']
BLUE_MAX = 15_000
CLASS_EVENTS = {'Amsterdam': 1945, 'Madrid': 1960}

def assign_age_class(data, events=CLASS_EVENTS):
    out = data.copy()
    out['age_class'] = pd.NA
    for city, ev in events.items():
        mask = out['city'] == city
        if mask.any():
            bins = [-np.inf, ev, 1984, 2004, np.inf]
            out.loc[mask, 'age_class'] = pd.cut(
                out.loc[mask, 'weighted_mean_year'], bins=bins, labels=[1, 2, 3, 4]
            ).astype('Int64')
    return out

def get_best_obs_band(data, band):
    col = np.full(len(data), np.nan)
    for slot in [1, 2, 3]:
        bc = f'{band}_{slot}'
        qc = f'qa_valid_{slot}'
        if bc not in data.columns or qc not in data.columns:
            continue
        valid = data[qc].fillna(False).values
        col = np.where(np.isnan(col) & valid, data[bc].fillna(np.nan).values, col)
    return col

def make_flat_view(data):
    keep = [c for c in ['pixel_id', 'city', 'year', 'px_key', 'py_key',
                        'weighted_mean_year', 'age_class'] if c in data.columns]
    out = data[keep].copy()
    for band in BASE_BANDS:
        out[band] = get_best_obs_band(data, band)
    out = out.dropna(subset=BASE_BANDS)
    n_before = len(out)
    out = out[out['Blue'] <= BLUE_MAX].copy()
    removed = n_before - len(out)
    if removed:
        city = data['city'].iloc[0] if 'city' in data.columns else ''
        print(f'  [{city}] Removed {removed:,} haze rows (Blue > {BLUE_MAX:,})')
    return out

def fill_time_series_gaps(flat):
    year_min = flat['year'].min()
    year_max = flat['year'].max()
    all_years = list(range(year_min, year_max + 1))
    pixels = flat[PID + ['city', 'weighted_mean_year', 'age_class']].drop_duplicates(PID)
    grid = pixels.assign(_k=1).merge(pd.DataFrame({'year': all_years, '_k': 1}), on='_k').drop('_k', axis=1)
    merged = grid.merge(flat[PID + ['year'] + BASE_BANDS], on=PID + ['year'], how='left')
    merged = merged.sort_values(PID + ['year'])
    def interp(s):
        s = s.interpolate(method='linear')
        return s.bfill().ffill()
    for band in BASE_BANDS:
        merged[band] = merged.groupby(PID)[band].transform(interp)
    return merged

def compute_spectral_indices(df):
    df = df.copy()
    B, G, R = df['Blue'], df['Green'], df['Red']
    N, S1, S2 = df['NIR'], df['SWIR1'], df['SWIR2']
    eps = 1e-6
    df['NDVI'] = (N - R) / (N + R + eps)
    df['NDBI'] = (S1 - N) / (S1 + N + eps)
    df['UI'] = (S2 - N) / (S2 + N + eps)
    df['MNDWI'] = (G - S1) / (G + S1 + eps)
    df['BSI'] = ((S1 + R) - (N + B)) / ((S1 + R) + (N + B) + eps)
    return df

def run_city(name, path):
    t0 = time.time()
    df = pd.read_parquet(path)
    df = assign_age_class(df)
    print(f'{name}: loaded {df.shape}', round(time.time()-t0,1))
    flat = make_flat_view(df)
    print(f'{name}: flattened {flat.shape}', round(time.time()-t0,1))
    flat = fill_time_series_gaps(flat)
    print(f'{name}: gap-filled {flat.shape}', round(time.time()-t0,1))
    flat = compute_spectral_indices(flat)
    print(f'{name}: indices added {flat.shape}', round(time.time()-t0,1))
    flat.to_parquet(f'/home/claude/work/pipeline/flat_{name.lower()}.parquet')
    print(f'{name}: saved. total {round(time.time()-t0,1)}s')
    return flat

if __name__ == '__main__':
    flat_madrid = run_city('Madrid', '/home/claude/work/realdata/madrid_train.parquet')
    flat_amsterdam = run_city('Amsterdam', '/home/claude/work/realdata/amsterdam_data.parquet')
