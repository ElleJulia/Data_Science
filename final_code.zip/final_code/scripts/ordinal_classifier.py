"""
Ordinal classifier chain (Frank & Hall, 2001), adapted for the Stage 1 model.

Why: the MapYourCity paper's single largest reported lever (Team Creamble,
Sec. IV-A) was modeling the fact that construction-epoch classes are
*ordinal* - Class 6 ('after 2006') is much closer to Class 5 ('1993-2006')
than to Class 0 ('before 1930'). Standard multi-class loss treats every
misclassification as equally bad, which throws that structure away. They
report ~2-3 point recall gains just from encoding this via soft/Gaussian
labels or label smoothing.

Your age classes (1-4) are exactly as ordinal - the whole hierarchy is built
on construction-period order. This module gives you the same effect without
needing a differentiable soft-label loss (which sklearn's tree ensembles
don't expose): it decomposes the K-class problem into K-1 binary problems
of the form "is the true class > k?", trains a probabilistic binary
classifier for each, and recombines them into calibrated class probabilities
that respect the ordering by construction - a prediction can't jump from
"probably Class 1" to "probably Class 4" without probability mass passing
through Class 2 and 3 first, which is exactly the adjacent-class confusion
pattern both this challenge and MapYourCity's confusion matrices show.

Usage (as a drop-in alternative Stage 1 candidate, alongside train_stage1.py):
    from scripts.ordinal_classifier import OrdinalClassifier
    from sklearn.ensemble import HistGradientBoostingClassifier
    clf = OrdinalClassifier(
        lambda: HistGradientBoostingClassifier(max_depth=6, learning_rate=0.06,
                                                max_iter=400, random_state=42)
    )
    clf.fit(X_madrid, y_madrid)
    proba = clf.predict_proba(X_ams)   # still usable by transfer_stage2.py's
                                        # self_training, which just needs
                                        # predict_proba + classes_
"""

from __future__ import annotations

import numpy as np


class OrdinalClassifier:
    """
    base_estimator_factory: a zero-arg callable returning a fresh, unfitted
    sklearn-compatible classifier with predict_proba (e.g. a lambda wrapping
    HistGradientBoostingClassifier or LogisticRegression). A fresh instance
    is trained per threshold so the K-1 binary models don't share state.
    """

    def __init__(self, base_estimator_factory):
        self.base_estimator_factory = base_estimator_factory
        self.classes_ = None
        self.binary_models_ = {}

    def fit(self, X, y):
        self.classes_ = np.sort(np.unique(y))
        # one binary model per threshold k: "is true class > classes_[k]?"
        for k in self.classes_[:-1]:
            y_bin = (y > k).astype(int)
            model = self.base_estimator_factory()
            model.fit(X, y_bin)
            self.binary_models_[k] = model
        return self

    def predict_proba(self, X):
        """
        Standard Frank & Hall recombination:
          P(y = c_0)   = 1 - P(y > c_0)
          P(y = c_i)   = P(y > c_{i-1}) - P(y > c_i)   for 0 < i < K-1
          P(y = c_K-1) = P(y > c_{K-2})
        """
        thresholds = self.classes_[:-1]
        p_gt = np.column_stack(
            [self.binary_models_[k].predict_proba(X)[:, 1] for k in thresholds]
        )  # shape (n_samples, K-1), P(y > threshold_k)

        n_classes = len(self.classes_)
        proba = np.zeros((X.shape[0], n_classes))
        proba[:, 0] = 1 - p_gt[:, 0]
        for i in range(1, n_classes - 1):
            proba[:, i] = np.clip(p_gt[:, i - 1] - p_gt[:, i], 0, None)
        proba[:, -1] = p_gt[:, -1]

        # numerical safety: renormalize rows (clipping negatives above can
        # make rows not sum to exactly 1)
        row_sums = proba.sum(axis=1, keepdims=True)
        row_sums[row_sums == 0] = 1.0
        return proba / row_sums

    def predict(self, X):
        proba = self.predict_proba(X)
        return self.classes_[np.argmax(proba, axis=1)]


if __name__ == "__main__":
    print(__doc__)
