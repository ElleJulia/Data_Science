"""
Metric learning for cross-city building-age transfer (improved).

Implements the approach in METRIC_LEARNING_APPROACH.md and extends it in
three ways that materially close the source->target gap the base method
suffers from:

  1. CORAL domain-alignment loss (Sun & Saenko 2016): during training, the
     embedding network sees *unlabeled* Amsterdam feature vectors and is
     penalised for producing different second-order statistics
     (mean + covariance) on Madrid vs. Amsterdam embeddings. This directly
     shrinks the "same building age looks different in each city" gap that
     causes zero-shot F1 to collapse.

  2. Ordinal-aware triplet margin: age classes are ordinal, so the margin
     is scaled by |y_a - y_n| - a class-4-vs-class-1 negative must be
     pushed further away than a class-2-vs-class-1 negative. This mirrors
     the Frank & Hall / ordinal-loss trick that gave the original pipeline
     its edge, but in embedding space.

  3. Auxiliary classification head + cross-entropy: adds a small softmax
     head trained jointly with the triplet loss. Two gradient signals
     converge faster than one; the classifier also gives us "Option C"
     from the writeup (logistic-regression-on-embeddings) essentially for
     free at inference time.

Architecture (with improved defaults):
    Input(F) -> Dense(128, ReLU) -> Dense(64, ReLU) -> Dense(embed_dim) -> L2
                                                      \\-> classifier head

Few-shot heads (all numpy-only, drop into any embedding matrix):
  - PrototypeClassifier            (Option B: nearest class mean)
  - ShrinkagePrototypeClassifier   (blends target-city mean with source-city
                                    mean via Empirical-Bayes shrinkage)
  - KNNClassifier                  (Option A: majority vote)
  - LogisticHead                   (Option C: sklearn LogisticRegression on
                                    the embedding)
  - OrdinalEmbeddingHead           (Frank & Hall ordinal chain on the
                                    embedding - respects age ordinality)
  - SelfTrainingHead               (source-model pseudo-labels + target
                                    labels, then fit a shallow classifier
                                    on the embedding)
"""

from __future__ import annotations

from dataclasses import dataclass, field
import numpy as np

try:
    import torch
    from torch import nn
    _HAS_TORCH = True
except ImportError:  # pragma: no cover
    torch = None
    nn = None
    _HAS_TORCH = False


# ---------------------------------------------------------------------------
# Embedding network (+ optional classifier head)
# ---------------------------------------------------------------------------

if _HAS_TORCH:

    class EmbeddingNet(nn.Module):
        """
        R^F -> R^embed_dim (L2-normalized).

        Optionally attaches a linear classifier head that operates on the
        pre-normalization features. The head is a linear projection to
        n_classes logits; kept intentionally shallow so most of the
        representational work still happens in the shared trunk.
        """

        def __init__(self, input_dim: int, embed_dim: int = 32,
                     hidden: tuple[int, ...] = (128, 64), dropout: float = 0.1,
                     n_classes: int | None = None):
            super().__init__()
            dims = [input_dim, *hidden]
            layers: list[nn.Module] = []
            for a, b in zip(dims[:-1], dims[1:]):
                layers.append(nn.Linear(a, b))
                layers.append(nn.BatchNorm1d(b))
                layers.append(nn.ReLU(inplace=True))
                if dropout > 0:
                    layers.append(nn.Dropout(dropout))
            self.trunk = nn.Sequential(*layers)
            self.embed = nn.Linear(dims[-1], embed_dim)
            self.classifier = nn.Linear(embed_dim, n_classes) if n_classes else None

        def forward(self, x, return_logits: bool = False, return_pre_norm: bool = False):
            h = self.trunk(x)
            z = self.embed(h)
            z_norm = nn.functional.normalize(z, p=2, dim=1)
            outs = [z_norm]
            if return_logits:
                if self.classifier is None:
                    outs.append(None)
                else:
                    # Attach the CE head to the pre-normalisation embedding.
                    # If we feed the L2-normalised vector, logit magnitude is
                    # bounded by ||w_k|| * 1, so softmax stays near-uniform
                    # and the CE gradient vanishes at ~log(K). Using the
                    # pre-norm `z` lets the classifier develop confident
                    # logits without breaking the L2 constraint used by the
                    # distance-based heads.
                    outs.append(self.classifier(z))
            if return_pre_norm:
                outs.append(z)
            if len(outs) == 1:
                return z_norm
            return tuple(outs)


# ---------------------------------------------------------------------------
# Loss functions
# ---------------------------------------------------------------------------


def _pairwise_sq_dist(z: "torch.Tensor") -> "torch.Tensor":
    return torch.clamp(2.0 - 2.0 * (z @ z.t()), min=0.0)


def batch_hard_triplet_loss(embeddings: "torch.Tensor",
                            labels: "torch.Tensor",
                            margin: float = 0.3,
                            ordinal: bool = True) -> "torch.Tensor":
    """
    Batch-hard triplet loss with an optional ordinal margin.

    Vanilla batch-hard (Hermans et al. 2017) uses a single scalar margin.
    When labels are ordinal (age epochs), we scale the margin by
    |y_anchor - y_negative| so a distant-class negative must be pushed
    proportionally farther. This makes the embedding respect class order,
    not just class identity.
    """
    d2 = _pairwise_sq_dist(embeddings)
    lab_col = labels.view(-1, 1)
    same = lab_col.eq(lab_col.t())
    diff = ~same
    eye = torch.eye(len(labels), dtype=torch.bool, device=embeddings.device)
    pos_mask = same & ~eye

    d2_pos = d2.masked_fill(~pos_mask, float("-inf"))
    hardest_pos, _ = d2_pos.max(dim=1)

    d2_neg = d2.masked_fill(~diff, float("inf"))
    hardest_neg, neg_idx = d2_neg.min(dim=1)

    valid = torch.isfinite(hardest_pos) & torch.isfinite(hardest_neg)
    if valid.sum() == 0:
        return torch.zeros((), device=embeddings.device, requires_grad=True)

    d_pos = torch.sqrt(hardest_pos[valid] + 1e-12)
    d_neg = torch.sqrt(hardest_neg[valid] + 1e-12)

    if ordinal:
        # margin_i = margin * |y_i - y_{n*(i)}|, clipped to >=1 so same-class
        # neighbours in ordinal space still get at least the base margin.
        neg_labels = labels[neg_idx][valid].float()
        anc_labels = labels[valid].float()
        gap = (anc_labels - neg_labels).abs().clamp(min=1.0)
        m = margin * gap
    else:
        m = margin

    loss = torch.clamp(d_pos - d_neg + m, min=0.0)
    return loss.mean()


def coral_loss(src: "torch.Tensor", tgt: "torch.Tensor") -> "torch.Tensor":
    """
    DeepCORAL (Sun & Saenko 2016). Aligns second-order statistics of source
    and target activations - penalises the Frobenius norm of the difference
    of their covariance matrices, normalised by 4*d^2.
    """
    d = src.shape[1]
    if src.shape[0] < 2 or tgt.shape[0] < 2:
        return torch.zeros((), device=src.device, requires_grad=True)
    src_c = src - src.mean(dim=0, keepdim=True)
    tgt_c = tgt - tgt.mean(dim=0, keepdim=True)
    cov_s = (src_c.t() @ src_c) / (src.shape[0] - 1)
    cov_t = (tgt_c.t() @ tgt_c) / (tgt.shape[0] - 1)
    return (cov_s - cov_t).pow(2).sum() / (4.0 * d * d)


# ---------------------------------------------------------------------------
# Class-balanced batch sampler (P classes x K instances)
# ---------------------------------------------------------------------------


class PKSampler:
    def __init__(self, y: np.ndarray, p_classes: int, k_per_class: int,
                 n_batches_per_epoch: int, rng: np.random.Generator):
        self.y = y
        self.p = p_classes
        self.k = k_per_class
        self.n_batches = n_batches_per_epoch
        self.rng = rng
        self.class_to_idx = {c: np.where(y == c)[0] for c in np.unique(y)}
        self.classes = list(self.class_to_idx.keys())

    def __iter__(self):
        for _ in range(self.n_batches):
            if len(self.classes) < self.p:
                sampled_classes = self.rng.choice(self.classes, self.p, replace=True)
            else:
                sampled_classes = self.rng.choice(self.classes, self.p, replace=False)
            batch = []
            for c in sampled_classes:
                pool = self.class_to_idx[c]
                replace = len(pool) < self.k
                batch.extend(self.rng.choice(pool, self.k, replace=replace).tolist())
            yield np.array(batch)


# ---------------------------------------------------------------------------
# Trainer
# ---------------------------------------------------------------------------


@dataclass
class TrainConfig:
    embed_dim: int = 32
    hidden: tuple = (128, 64)
    dropout: float = 0.1
    lr: float = 1e-3
    weight_decay: float = 1e-5
    margin: float = 0.4
    ordinal_margin: bool = True
    epochs: int = 200
    p_classes: int = 4
    k_per_class: int = 24
    n_batches_per_epoch: int = 80
    val_every: int = 5
    early_stop_patience: int = 30
    coral_weight: float = 50.0      # weight of CORAL domain-alignment loss
                                    # (raw CORAL is small in absolute terms
                                    # after the trunk's BN + Dense projection,
                                    # so it needs a large multiplier to
                                    # meaningfully compete with the triplet
                                    # and CE terms in the total loss.)
    ce_weight: float = 1.0          # weight of cross-entropy auxiliary loss
    lr_gamma: float = 0.95          # exponential LR decay factor per epoch
    tgt_batch: int = 256            # per-step Amsterdam samples for CORAL
    seed: int = 42
    device: str = "cpu"


class MetricLearner:
    """
    Train an L2-normalized embedding on (X_source, y_source), optionally
    with unlabeled X_target for CORAL alignment and an auxiliary classifier
    head for cross-entropy supervision. Exposes .embed(X) for downstream heads.
    """

    def __init__(self, config: TrainConfig | None = None):
        if not _HAS_TORCH:
            raise ImportError("MetricLearner requires PyTorch")
        self.config = config or TrainConfig()
        self.model: EmbeddingNet | None = None
        self.classes_: np.ndarray | None = None
        self.history: list[dict] = []

    def _seed(self):
        torch.manual_seed(self.config.seed)
        np.random.seed(self.config.seed)

    def fit(self, X: np.ndarray, y: np.ndarray,
            X_val: np.ndarray | None = None, y_val: np.ndarray | None = None,
            X_target: np.ndarray | None = None,
            verbose: bool = True):
        cfg = self.config
        self._seed()
        device = torch.device(cfg.device)

        classes = np.array(sorted(np.unique(y)))
        self.classes_ = classes
        class_to_ix = {c: i for i, c in enumerate(classes)}
        y_ix = np.array([class_to_ix[c] for c in y])

        X_t = torch.as_tensor(X, dtype=torch.float32, device=device)
        y_t = torch.as_tensor(y_ix, dtype=torch.long, device=device)
        # keep original labels around for ordinal margin (batch-hard uses raw
        # class integers, not remapped indices, so the |y_a - y_n| gap has
        # the intended ordinal meaning).
        y_raw_t = torch.as_tensor(y, dtype=torch.long, device=device)

        X_tgt_t = None
        if X_target is not None and cfg.coral_weight > 0:
            X_tgt_t = torch.as_tensor(X_target, dtype=torch.float32, device=device)

        self.model = EmbeddingNet(
            X.shape[1], cfg.embed_dim, cfg.hidden, cfg.dropout,
            n_classes=len(classes) if cfg.ce_weight > 0 else None,
        ).to(device)
        opt = torch.optim.Adam(self.model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)
        sched = torch.optim.lr_scheduler.ExponentialLR(opt, gamma=cfg.lr_gamma)
        ce = nn.CrossEntropyLoss()

        rng = np.random.default_rng(cfg.seed)
        sampler = PKSampler(y_ix, cfg.p_classes, cfg.k_per_class,
                            cfg.n_batches_per_epoch, rng)

        best_val = float("-inf")
        best_state = None
        no_improve = 0

        for epoch in range(1, cfg.epochs + 1):
            self.model.train()
            tri_losses, ce_losses, coral_losses = [], [], []
            for batch_idx in sampler:
                idx = torch.as_tensor(batch_idx, dtype=torch.long, device=device)
                xb = X_t[idx]
                zb, logits, zb_raw = self.model(xb, return_logits=True, return_pre_norm=True)

                # ordinal-aware batch-hard triplet loss on raw ordinal labels
                loss_tri = batch_hard_triplet_loss(zb, y_raw_t[idx],
                                                   margin=cfg.margin,
                                                   ordinal=cfg.ordinal_margin)

                loss = loss_tri
                tri_losses.append(float(loss_tri.item()))

                if logits is not None:
                    loss_ce = ce(logits, y_t[idx])
                    loss = loss + cfg.ce_weight * loss_ce
                    ce_losses.append(float(loss_ce.item()))

                if X_tgt_t is not None:
                    # sample a fresh Amsterdam sub-batch each step
                    tgt_idx = torch.randint(0, X_tgt_t.shape[0], (cfg.tgt_batch,),
                                            device=device)
                    _, _, z_tgt_raw = self.model(X_tgt_t[tgt_idx],
                                                  return_logits=True,
                                                  return_pre_norm=True)
                    # CORAL on pre-L2-norm activations: L2-normalising two
                    # samples onto a unit hypersphere makes their covariances
                    # trivially close no matter the domain gap, so the L2
                    # output is a bad place to align. Aligning the pre-norm
                    # activations lets CORAL actually see (and shrink) the
                    # Madrid-vs-Amsterdam scale/shape mismatch.
                    loss_c = coral_loss(zb_raw, z_tgt_raw)
                    loss = loss + cfg.coral_weight * loss_c
                    coral_losses.append(float(loss_c.item()))

                opt.zero_grad()
                loss.backward()
                opt.step()

            sched.step()
            mean_tri = float(np.mean(tri_losses)) if tri_losses else float("nan")
            mean_ce  = float(np.mean(ce_losses))  if ce_losses  else 0.0
            mean_co  = float(np.mean(coral_losses)) if coral_losses else 0.0

            entry = {"epoch": epoch, "train_tri": mean_tri, "train_ce": mean_ce, "train_coral": mean_co}

            if X_val is not None and (epoch % cfg.val_every == 0 or epoch == cfg.epochs):
                val_score = self._prototype_score(X, y, X_val, y_val)
                entry["val_proto_f1"] = val_score
                if val_score > best_val + 1e-4:
                    best_val, no_improve = val_score, 0
                    best_state = {k: v.detach().clone() for k, v in self.model.state_dict().items()}
                else:
                    no_improve += cfg.val_every
                if verbose:
                    print(f"    epoch {epoch:3d}  tri={mean_tri:.3f}  ce={mean_ce:.3f}"
                          f"  coral={mean_co:.4f}  val_proto_f1={val_score:.4f}"
                          f"  (best={best_val:.4f})")
                if no_improve >= cfg.early_stop_patience:
                    if verbose:
                        print(f"    early stop at epoch {epoch}")
                    break
            self.history.append(entry)

        if best_state is not None:
            self.model.load_state_dict(best_state)
        return self

    def embed(self, X: np.ndarray, batch_size: int = 8192) -> np.ndarray:
        assert self.model is not None
        self.model.eval()
        device = next(self.model.parameters()).device
        outs = []
        with torch.no_grad():
            for start in range(0, len(X), batch_size):
                end = min(start + batch_size, len(X))
                xb = torch.as_tensor(X[start:end], dtype=torch.float32, device=device)
                outs.append(self.model(xb).cpu().numpy())
        return np.concatenate(outs, axis=0)

    def embed_target_tta(self, X_target: np.ndarray, batch_size: int = 8192,
                          adapt_batches: int = 4) -> np.ndarray:
        """
        Test-time BatchNorm adaptation: before embedding the target city, run
        a few forward passes over its own data in train() mode so BN's
        running_mean/var track the target-domain activation statistics
        instead of the Madrid statistics that were baked in during training.

        Then embed in eval() mode as usual. This is a well-known TTA trick
        that gives 1-3% F1 on cross-domain benchmarks basically for free -
        no gradients, no target labels required.
        """
        assert self.model is not None
        device = next(self.model.parameters()).device
        X_t = torch.as_tensor(X_target, dtype=torch.float32, device=device)

        # snapshot current BN running stats so we can restore them
        bn_backup = {}
        for name, mod in self.model.named_modules():
            if isinstance(mod, nn.BatchNorm1d):
                bn_backup[name] = (mod.running_mean.detach().clone(),
                                    mod.running_var.detach().clone(),
                                    float(mod.momentum) if mod.momentum is not None else 0.1,
                                    int(mod.num_batches_tracked.item()))
                # bump momentum so a handful of adapt batches actually shift
                # the running stats (default 0.1 needs ~10 batches).
                mod.momentum = 0.3

        self.model.train()
        with torch.no_grad():
            for _ in range(adapt_batches):
                perm = torch.randperm(len(X_t), device=device)[:min(len(X_t), batch_size)]
                _ = self.model(X_t[perm])

        # embed in eval mode with the adapted running stats
        self.model.eval()
        outs = []
        with torch.no_grad():
            for start in range(0, len(X_t), batch_size):
                end = min(start + batch_size, len(X_t))
                outs.append(self.model(X_t[start:end]).cpu().numpy())

        # restore original BN stats so calling code doesn't leak target
        # statistics into subsequent source-side calls
        for name, mod in self.model.named_modules():
            if isinstance(mod, nn.BatchNorm1d) and name in bn_backup:
                rm, rv, mom, nbt = bn_backup[name]
                mod.running_mean.copy_(rm)
                mod.running_var.copy_(rv)
                mod.momentum = mom
                mod.num_batches_tracked.zero_().add_(nbt)

        return np.concatenate(outs, axis=0)

    def predict_proba_classifier(self, X: np.ndarray, batch_size: int = 8192) -> np.ndarray | None:
        """Softmax probabilities from the auxiliary classifier head, if present."""
        assert self.model is not None
        if self.model.classifier is None:
            return None
        self.model.eval()
        device = next(self.model.parameters()).device
        outs = []
        with torch.no_grad():
            for start in range(0, len(X), batch_size):
                end = min(start + batch_size, len(X))
                xb = torch.as_tensor(X[start:end], dtype=torch.float32, device=device)
                _, logits = self.model(xb, return_logits=True)
                outs.append(torch.softmax(logits, dim=1).cpu().numpy())
        return np.concatenate(outs, axis=0)

    def _prototype_score(self, X_tr, y_tr, X_val, y_val) -> float:
        from sklearn.metrics import f1_score
        z_tr = self.embed(X_tr)
        z_val = self.embed(X_val)
        clf = PrototypeClassifier().fit(z_tr, y_tr)
        return f1_score(y_val, clf.predict(z_val), average="macro")


# ---------------------------------------------------------------------------
# Few-shot heads (numpy-only where possible)
# ---------------------------------------------------------------------------


class PrototypeClassifier:
    def __init__(self):
        self.classes_ = None
        self.prototypes_ = None

    def fit(self, Z, y):
        self.classes_ = np.array(sorted(np.unique(y)))
        self.prototypes_ = np.stack([Z[y == c].mean(axis=0) for c in self.classes_])
        norms = np.linalg.norm(self.prototypes_, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        self.prototypes_ = self.prototypes_ / norms
        return self

    def predict(self, Z):
        d = np.linalg.norm(Z[:, None, :] - self.prototypes_[None, :, :], axis=2)
        return self.classes_[d.argmin(axis=1)]


class ShrinkagePrototypeClassifier:
    def __init__(self, source_prototypes: dict, alpha: float = 5.0):
        self.source_prototypes = source_prototypes
        self.alpha = alpha
        self.classes_ = None
        self.prototypes_ = None

    def fit(self, Z, y):
        self.classes_ = np.array(sorted(np.unique(y)))
        blended = []
        for c in self.classes_:
            z_c = Z[y == c]
            n_k = len(z_c)
            if int(c) in self.source_prototypes:
                src = self.source_prototypes[int(c)]
                if n_k == 0:
                    proto = src
                else:
                    proto = (n_k * z_c.mean(axis=0) + self.alpha * src) / (n_k + self.alpha)
            else:
                proto = z_c.mean(axis=0)
            proto = proto / max(np.linalg.norm(proto), 1e-12)
            blended.append(proto)
        self.prototypes_ = np.stack(blended)
        return self

    def predict(self, Z):
        d = np.linalg.norm(Z[:, None, :] - self.prototypes_[None, :, :], axis=2)
        return self.classes_[d.argmin(axis=1)]


class TransductivePrototypeClassifier:
    """
    Transductive few-shot head: refines class prototypes using the query
    pool via soft-assignment iterations (TPN / SimpleShot family).

    Init:  proto_c = mean of the n_c support embeddings for class c
    Repeat T times:
        d2_qc = ||z_q - proto_c||^2
        w     = softmax_c(-tau * d2_qc)              # (Nq, C)
        qmean_c = weighted mean of Z_query using w[:,c] as weights (row-normalised)
        proto_c = (support_weight * sup_mean_c + qmean_c) / (support_weight + 1)
        renormalise onto the unit sphere.

    Critical: use *means* not sums for support and query contributions.
    A 25k-pixel Amsterdam query pool would otherwise swamp a n=5 support set
    by a factor of 5000 and drag the prototype off toward the pool's centre
    of mass regardless of what the support labels say.
    """

    def __init__(self, tau: float = 10.0, n_iters: int = 10,
                 support_weight: float = 3.0):
        self.tau = tau
        self.n_iters = n_iters
        self.support_weight = support_weight
        self.classes_: np.ndarray | None = None
        self.prototypes_: np.ndarray | None = None

    def fit(self, Z_support, y_support, Z_query=None):
        self.classes_ = np.array(sorted(np.unique(y_support)))
        # support means (fixed anchor across iterations)
        sup_mean = np.stack([Z_support[y_support == c].mean(axis=0) for c in self.classes_])
        sup_mean = sup_mean / np.maximum(np.linalg.norm(sup_mean, axis=1, keepdims=True), 1e-12)
        proto = sup_mean.copy()

        if Z_query is not None and len(Z_query) > 0 and self.n_iters > 0:
            zq_sq = np.sum(Z_query * Z_query, axis=1, keepdims=True)  # (Nq, 1)
            sw = float(self.support_weight)
            for _ in range(self.n_iters):
                p_sq = np.sum(proto * proto, axis=1)               # (C,)
                d2 = zq_sq + p_sq - 2 * Z_query @ proto.T
                d2 = np.maximum(d2, 0.0)
                w = _softmax(-self.tau * d2, axis=1)               # (Nq, C)
                # per-class weighted-mean of queries; guard empty classes
                w_sum = np.maximum(w.sum(axis=0, keepdims=True), 1e-12)  # (1, C)
                qmean = (w.T @ Z_query) / w_sum.T                  # (C, D)
                # blend support mean (dominant, sw:1) with query mean
                proto = (sw * sup_mean + qmean) / (sw + 1.0)
                proto = proto / np.maximum(np.linalg.norm(proto, axis=1, keepdims=True), 1e-12)

        self.prototypes_ = proto
        return self

    def predict(self, Z):
        d = np.linalg.norm(Z[:, None, :] - self.prototypes_[None, :, :], axis=2)
        return self.classes_[d.argmin(axis=1)]


def _softmax(x: np.ndarray, axis: int = -1) -> np.ndarray:
    x = x - x.max(axis=axis, keepdims=True)
    e = np.exp(x)
    return e / np.maximum(e.sum(axis=axis, keepdims=True), 1e-12)


class KNNClassifier:
    def __init__(self, k: int = 5):
        self.k = k
        self.Z_ = None
        self.y_ = None
        self.classes_ = None

    def fit(self, Z, y):
        self.Z_ = Z
        self.y_ = y
        self.classes_ = np.array(sorted(np.unique(y)))
        return self

    def predict(self, Z):
        k = min(self.k, len(self.Z_))
        out = np.empty(len(Z), dtype=self.y_.dtype)
        chunk = 4096
        for s in range(0, len(Z), chunk):
            e = min(s + chunk, len(Z))
            d = np.linalg.norm(Z[s:e, None, :] - self.Z_[None, :, :], axis=2)
            nn_idx = np.argpartition(d, kth=k - 1, axis=1)[:, :k]
            nn_lbl = self.y_[nn_idx]
            out[s:e] = _mode_rows(nn_lbl, self.classes_)
        return out


class LogisticHead:
    """Option C from the writeup: a logistic regression classifier fit on
    the (few-shot) target embeddings. Beats prototype at higher n."""

    def __init__(self, C: float = 10.0):
        from sklearn.linear_model import LogisticRegression
        # Support sets are class-balanced already, so class_weight is a no-op
        # (worse: it can push the boundary the wrong way when the *query* set
        # is imbalanced). Larger C -> less regularisation -> prevents
        # collapse-to-prior at n=5-25.
        self._make = lambda: LogisticRegression(C=C, max_iter=1000)
        self.clf = None

    def fit(self, Z, y):
        self.clf = self._make()
        if len(np.unique(y)) < 2:
            # LogReg fails with a single class; fall back to prototype
            self.clf = PrototypeClassifier().fit(Z, y)
        else:
            self.clf.fit(Z, y)
        return self

    def predict(self, Z):
        return self.clf.predict(Z)


class OrdinalEmbeddingHead:
    """
    Frank & Hall ordinal chain (K-1 binary classifiers) fit on the target-
    domain embedding. Encodes age-class ordinality that plain prototype/kNN
    throw away.
    """

    def __init__(self, C: float = 10.0):
        from sklearn.linear_model import LogisticRegression
        self._factory = lambda: LogisticRegression(C=C, max_iter=1000)
        self.classes_ = None
        self.models_ = {}

    def fit(self, Z, y):
        self.classes_ = np.array(sorted(np.unique(y)))
        if len(self.classes_) < 2:
            self._fallback = PrototypeClassifier().fit(Z, y)
            return self
        self._fallback = None
        for k in self.classes_[:-1]:
            y_bin = (y > k).astype(int)
            if len(np.unique(y_bin)) < 2:
                # skip degenerate threshold
                continue
            m = self._factory()
            m.fit(Z, y_bin)
            self.models_[int(k)] = m
        return self

    def predict(self, Z):
        if self._fallback is not None:
            return self._fallback.predict(Z)
        thresholds = self.classes_[:-1]
        cols = []
        for k in thresholds:
            if int(k) in self.models_:
                cols.append(self.models_[int(k)].predict_proba(Z)[:, 1])
            else:
                cols.append(np.zeros(Z.shape[0]))
        p_gt = np.column_stack(cols)
        n_c = len(self.classes_)
        proba = np.zeros((Z.shape[0], n_c))
        proba[:, 0] = 1 - p_gt[:, 0]
        for i in range(1, n_c - 1):
            proba[:, i] = np.clip(p_gt[:, i - 1] - p_gt[:, i], 0, None)
        proba[:, -1] = p_gt[:, -1]
        return self.classes_[np.argmax(proba, axis=1)]


class SelfTrainingHead:
    """
    Embedding-space self-training: pool the target support labels with
    high-confidence source-classifier pseudo-labels on the target query
    pool, then fit a logistic-regression head on the augmented set.

    Requires precomputed `source_proba` (from the auxiliary classifier or a
    prototype-based soft classifier) over the target *pool*, aligned to the
    embedding row order. The `pool_mask` marks which rows in that pool are
    still unlabeled (i.e. not in the current support set).
    """

    def __init__(self, confidence_threshold: float = 0.7,
                 max_pseudo_per_class: int = 300, C: float = 5.0):
        from sklearn.linear_model import LogisticRegression
        self.thr = confidence_threshold
        self.max_pseudo = max_pseudo_per_class
        self.C = C
        self._factory = lambda: LogisticRegression(
            C=C, max_iter=1000, class_weight="balanced",
        )
        self.clf = None
        self.classes_ = None

    def fit(self, Z_support, y_support, Z_query, source_proba_query, classes):
        classes = np.array(sorted(classes))
        conf = source_proba_query.max(axis=1)
        pseudo = classes[source_proba_query.argmax(axis=1)]
        keep = []
        for c in classes:
            c_idx = np.where((pseudo == c) & (conf >= self.thr))[0]
            if len(c_idx) > self.max_pseudo:
                c_idx = c_idx[np.argsort(-conf[c_idx])[:self.max_pseudo]]
            keep.extend(c_idx.tolist())
        if keep:
            Zp, yp = Z_query[keep], pseudo[keep]
            Z_train = np.vstack([Z_support, Zp])
            y_train = np.concatenate([y_support, yp])
        else:
            Z_train, y_train = Z_support, y_support
        if len(np.unique(y_train)) < 2:
            self.clf = PrototypeClassifier().fit(Z_train, y_train)
        else:
            self.clf = self._factory().fit(Z_train, y_train)
        self.classes_ = classes
        return self

    def predict(self, Z):
        return self.clf.predict(Z)


def _mode_rows(labels: np.ndarray, class_order: np.ndarray) -> np.ndarray:
    out = np.empty(labels.shape[0], dtype=labels.dtype)
    for i, row in enumerate(labels):
        counts = np.bincount(row, minlength=int(class_order.max()) + 1)
        out[i] = counts.argmax()
    return out


# ---------------------------------------------------------------------------
# Convenience: source-side prototypes (unit-normalised class means)
# ---------------------------------------------------------------------------


def source_prototypes_from(learner, X_src: np.ndarray,
                           y_src: np.ndarray) -> dict:
    z = learner.embed(X_src)
    protos = {}
    for c in np.unique(y_src):
        v = z[y_src == c].mean(axis=0)
        protos[int(c)] = v / max(np.linalg.norm(v), 1e-12)
    return protos


# ---------------------------------------------------------------------------
# Ensemble: train K learners with different seeds, concatenate their
# L2-normalised embeddings, re-normalise. Cheap, always-helps deep-learning
# baseline. Each member sees the same data with different weight init and
# batch order, so their errors are partly de-correlated - concatenating +
# renormalising gives a "consensus" embedding that reliably outperforms any
# single member.
# ---------------------------------------------------------------------------


_DIVERSITY_GRID = [
    # (embed_dim, hidden, margin, dropout)
    (32, (128, 64), 0.40, 0.10),   # base config
    (16, (128, 64), 0.30, 0.10),   # smaller embedding, softer margin
    (48, (128, 64), 0.50, 0.15),   # bigger embedding, harder margin
    (32, (160, 80), 0.40, 0.05),   # wider trunk, less dropout
    (32, (128, 64), 0.35, 0.20),   # more dropout for regularisation
]


class MetricLearnerEnsemble:
    """
    Container over K MetricLearner instances. Members are diversified in
    architecture + margin + dropout so their decision boundaries decorrelate
    - concatenating five identical-config models mostly just averages the
    same minimum, while five varied-config models actually vote on distinct
    hypotheses. Their L2-normalised outputs are concatenated (varying dims
    is fine) and re-normalised.
    """

    def __init__(self, config: TrainConfig, n_models: int = 5, diversify: bool = True):
        self.base_config = config
        self.n_models = n_models
        self.diversify = diversify
        self.learners: list[MetricLearner] = []
        self.classes_ = None

    def _member_config(self, i: int) -> TrainConfig:
        cfg_dict = self.base_config.__dict__.copy()
        cfg_dict["seed"] = self.base_config.seed + 1000 * i
        if self.diversify:
            slot = _DIVERSITY_GRID[i % len(_DIVERSITY_GRID)]
            embed_dim, hidden, margin, dropout = slot
            cfg_dict.update(dict(embed_dim=embed_dim, hidden=hidden,
                                 margin=margin, dropout=dropout))
        return TrainConfig(**cfg_dict)

    def fit(self, X, y, X_val=None, y_val=None, X_target=None, verbose: bool = True):
        for i in range(self.n_models):
            cfg = self._member_config(i)
            if verbose:
                print(f"  --- member {i+1}/{self.n_models}  "
                      f"embed_dim={cfg.embed_dim}  margin={cfg.margin}  "
                      f"dropout={cfg.dropout}  hidden={cfg.hidden} ---", flush=True)
            learner = MetricLearner(cfg).fit(
                X, y, X_val=X_val, y_val=y_val, X_target=X_target, verbose=verbose,
            )
            self.learners.append(learner)
        self.classes_ = self.learners[0].classes_
        return self

    def embed(self, X: np.ndarray) -> np.ndarray:
        parts = [lr.embed(X) for lr in self.learners]
        z = np.concatenate(parts, axis=1)
        norms = np.linalg.norm(z, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        return z / norms

    def embed_target_tta(self, X_target: np.ndarray, adapt_batches: int = 4) -> np.ndarray:
        """Target-domain BN adaptation, applied per member, then concatenated."""
        parts = [lr.embed_target_tta(X_target, adapt_batches=adapt_batches)
                 for lr in self.learners]
        z = np.concatenate(parts, axis=1)
        norms = np.linalg.norm(z, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        return z / norms

    def predict_proba_classifier(self, X: np.ndarray):
        """Average softmax probabilities across members that have a head."""
        probas = []
        for lr in self.learners:
            p = lr.predict_proba_classifier(X)
            if p is not None:
                probas.append(p)
        if not probas:
            return None
        return np.mean(probas, axis=0)


# ---------------------------------------------------------------------------
# Model persistence (deliverable #1 in the submission spec)
# ---------------------------------------------------------------------------


def save_learner(path: str, learner, extras: dict | None = None):
    """
    Save a MetricLearner or MetricLearnerEnsemble to `path`. Stores enough to
    reconstruct the network(s) and re-embed new feature vectors: architecture
    hyperparameters, weights, class list, and optional side-car objects like
    the fitted StandardScaler and the feature-column list.
    """
    if not _HAS_TORCH:
        raise ImportError("save_learner requires PyTorch")

    def _pack_single(lr: "MetricLearner") -> dict:
        cfg = lr.config
        return {
            "state_dict": lr.model.state_dict(),
            "config": {
                "embed_dim": cfg.embed_dim,
                "hidden": list(cfg.hidden),
                "dropout": cfg.dropout,
                "margin": cfg.margin,
                "ordinal_margin": cfg.ordinal_margin,
                "coral_weight": cfg.coral_weight,
                "ce_weight": cfg.ce_weight,
                "epochs": cfg.epochs,
                "seed": cfg.seed,
            },
            "input_dim": lr.model.trunk[0].in_features,
            "classes_": lr.classes_.tolist() if lr.classes_ is not None else None,
        }

    if isinstance(learner, MetricLearnerEnsemble):
        payload = {
            "kind": "ensemble",
            "n_models": learner.n_models,
            "members": [_pack_single(lr) for lr in learner.learners],
        }
    else:
        payload = {"kind": "single", **_pack_single(learner)}

    payload["extras"] = extras or {}
    torch.save(payload, path)
    return path


if __name__ == "__main__":
    print(__doc__)
