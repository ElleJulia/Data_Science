"""
Vectorized version of build_extended_features(), for real-scale data.

The original implementation in feature_engineering_extra.py loops over each
pixel group in pure Python and does an O(n^2) pairwise Theil-Sen computation
per pixel per band. That's fine for a few thousand synthetic pixels but does
not scale to real competition data (76K Madrid + 26K Amsterdam pixels) -
benchmarking on a 2000-pixel subset alone exceeded 300s, which extrapolates
to well over an hour for the full dataset. That's not a resource budget a
hackathon affords.

This module produces the *same feature columns* as build_extended_features(),
but computes them as dense (n_pixels x n_years) matrices instead of a Python
loop over groups, since fill_time_series_gaps() in the starter notebook
already guarantees every pixel shares one common, fully-populated year grid
(1984-2025) - that alignment is exactly what makes the vectorized approach
possible: no per-pixel ragged-array handling is needed.

Usage (drop-in replacement for feature_engineering_extra.build_extended_features):
    from scripts.feature_engineering_extra_fast import build_extended_features_fast
    ext_madrid    = build_extended_features_fast(flat_madrid)
    ext_amsterdam = build_extended_features_fast(flat_amsterdam)
"""

from __future__ import annotations

import numpy as np
import pandas as pd

BASE_BANDS = ["Blue", "Green", "Red", "NIR", "SWIR1", "SWIR2"]
INDEX_COLS = ["NDVI", "NDBI", "UI", "MNDWI", "BSI"]
PID = ["px_key", "py_key"]
DECADE_EDGES = [1984, 1994, 2004, 2014, 2025]


def _pivot_to_matrix(flat: pd.DataFrame, col: str, pixel_order: pd.MultiIndex, years: np.ndarray) -> np.ndarray:
    """Returns a (n_pixels, n_years) float32 matrix, row order = pixel_order, col order = years."""
    piv = flat.pivot_table(index=PID, columns="year", values=col, aggfunc="first")
    piv = piv.reindex(index=pixel_order, columns=years)
    return piv.to_numpy(dtype=np.float32)


def _theil_sen_slopes_vectorized(mat: np.ndarray, years: np.ndarray) -> np.ndarray:
    """
    mat: (n_pixels, n_years). Returns (n_pixels,) median pairwise slope per row.
    Years are shared across all pixels (post gap-filling), so the pairwise
    year-difference matrix is computed once and reused for every pixel.
    """
    n_years = len(years)
    iu = np.triu_indices(n_years, k=1)
    dy_years = (years[iu[1]] - years[iu[0]]).astype(np.float32)  # (n_pairs,)

    # process in row-chunks to bound peak memory (n_pairs can be ~860 for 42 years)
    n_pixels = mat.shape[0]
    chunk = max(1, min(n_pixels, 20_000_000 // max(len(iu[0]), 1)))
    out = np.empty(n_pixels, dtype=np.float32)
    for start in range(0, n_pixels, chunk):
        end = min(start + chunk, n_pixels)
        block = mat[start:end]  # (b, n_years)
        dv = block[:, iu[1]] - block[:, iu[0]]  # (b, n_pairs)
        slopes = dv / dy_years[None, :]
        out[start:end] = np.nanmedian(slopes, axis=1)
    return out


def _decade_stats(mat: np.ndarray, years: np.ndarray, prefix: str) -> dict:
    out = {}
    for lo, hi in zip(DECADE_EDGES[:-1], DECADE_EDGES[1:]):
        mask = (years >= lo) & (years < hi)
        sub = mat[:, mask]
        with np.errstate(invalid="ignore"):
            out[f"{prefix}_dec_{lo}_{hi}_mean"] = np.nanmean(sub, axis=1)
            # ddof=1 to match pandas' default (sample) std used by the slow
            # reference implementation; guard against decade windows with a
            # single valid year, where ddof=1 std is undefined (NaN is fine -
            # it gets median-filled downstream like any other sparse window).
            out[f"{prefix}_dec_{lo}_{hi}_std"] = np.nanstd(sub, axis=1, ddof=1)
    return out


def _extrema_and_jump(mat: np.ndarray, years: np.ndarray, prefix: str) -> dict:
    out = {}
    valid = ~np.isnan(mat)
    any_valid = valid.any(axis=1)

    filled_for_argmax = np.where(valid, mat, -np.inf)
    filled_for_argmin = np.where(valid, mat, np.inf)
    idx_max = np.argmax(filled_for_argmax, axis=1)
    idx_min = np.argmin(filled_for_argmin, axis=1)
    out[f"{prefix}_year_of_max"] = np.where(any_valid, years[idx_max].astype(np.float32), np.nan)
    out[f"{prefix}_year_of_min"] = np.where(any_valid, years[idx_min].astype(np.float32), np.nan)

    diffs = np.diff(mat, axis=1)  # (n_pixels, n_years-1), NaN-safe via nan propagation
    abs_diffs = np.abs(diffs)
    has_diff = ~np.all(np.isnan(abs_diffs), axis=1)
    filled = np.where(np.isnan(abs_diffs), -np.inf, abs_diffs)
    jump_idx = np.argmax(filled, axis=1)
    max_jump = np.take_along_axis(abs_diffs, jump_idx[:, None], axis=1).ravel()
    jump_year = years[1:][jump_idx].astype(np.float32)  # year *after* the jump
    out[f"{prefix}_max_jump"] = np.where(has_diff, max_jump, 0.0)
    out[f"{prefix}_max_jump_year"] = np.where(has_diff, jump_year, np.nan)
    return out


def build_extended_features_fast(flat: pd.DataFrame) -> pd.DataFrame:
    """Vectorized drop-in replacement for feature_engineering_extra.build_extended_features()."""
    s = flat[flat["age_class"].notna()].copy() if "age_class" in flat.columns else flat.copy()
    pixel_order = pd.MultiIndex.from_frame(
        s[PID].drop_duplicates().sort_values(PID).reset_index(drop=True)
    )
    years = np.sort(s["year"].unique())

    feats = {}
    for col in BASE_BANDS + INDEX_COLS:
        mat = _pivot_to_matrix(s, col, pixel_order, years)
        feats.update(_decade_stats(mat, years, col))
        if col in BASE_BANDS:
            feats[f"{col}_trend_slope"] = _theil_sen_slopes_vectorized(mat, years.astype(np.float32))
            feats.update(_extrema_and_jump(mat, years, col))
        del mat

    ext = pd.DataFrame(feats, index=pixel_order).reset_index()
    numeric_cols = [c for c in ext.columns if c not in PID]
    ext[numeric_cols] = ext[numeric_cols].fillna(ext[numeric_cols].median(numeric_only=True))
    return ext


if __name__ == "__main__":
    print(__doc__)
