"""Reproduces Notebook 3's baseline build_pixel_features() so the validation
run can merge it with the extended features, exactly like a real notebook
run would. Not part of the shipped strategy scripts - just needed here so
this validation script doesn't depend on the actual notebook file."""
import numpy as np
import pandas as pd

BASE_BANDS = ["Blue", "Green", "Red", "NIR", "SWIR1", "SWIR2"]
INDEX_COLS = ["NDVI", "NDBI", "UI", "MNDWI", "BSI"]
PID = ["px_key", "py_key"]
EARLY_CUTOFF, LATE_START = 2003, 2004


def build_pixel_features(flat: pd.DataFrame) -> pd.DataFrame:
    s = flat[flat["age_class"].notna()].copy()
    s = s.sort_values(PID + ["year"])

    grp = s.groupby(PID + ["age_class"])
    overall = pd.concat([
        grp[BASE_BANDS + INDEX_COLS].mean().add_suffix("_mean"),
        grp[BASE_BANDS + INDEX_COLS].std().add_suffix("_std"),
    ], axis=1).reset_index()
    overall["age_class"] = overall["age_class"].astype(int)

    early_grp = s[s["year"] <= EARLY_CUTOFF].groupby(PID)
    early = pd.concat([
        early_grp[BASE_BANDS].mean().add_suffix("_early_mean"),
        early_grp[BASE_BANDS].std().add_suffix("_early_std"),
    ], axis=1).reset_index()

    late_grp = s[s["year"] >= LATE_START].groupby(PID)
    late = pd.concat([
        late_grp[BASE_BANDS].mean().add_suffix("_late_mean"),
        late_grp[BASE_BANDS].std().add_suffix("_late_std"),
    ], axis=1).reset_index()

    for b in BASE_BANDS:
        s[f"d_{b}"] = s.groupby(PID)[b].diff()
    dcols = [f"d_{b}" for b in BASE_BANDS]
    diff_grp = s.groupby(PID)[dcols]
    diff = pd.concat([
        diff_grp.mean().add_suffix("_mean"),
        diff_grp.std().add_suffix("_std"),
    ], axis=1).reset_index()

    yr = s.groupby(PID)["weighted_mean_year"].first().reset_index()

    result = overall
    for extra in [early, late, diff, yr]:
        result = result.merge(extra, on=PID, how="left")

    result = result.fillna(0.0)
    return result
