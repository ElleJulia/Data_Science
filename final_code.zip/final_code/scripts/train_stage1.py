"""
Stage 1: train and cross-validate a Madrid model, competing several
class-imbalance-aware classifiers and picking the best by macro F1.

Why go beyond the Notebook 4 baseline (a single un-tuned RandomForest)?
- The baseline explicitly does NOT correct for class imbalance beyond
  `class_weight='balanced'`, and the notebook's own confusion matrix shows
  Class 1 being systematically absorbed into Class 2. Testing several
  imbalance-aware options (balanced RF, HistGradientBoosting with sample
  weights, and a soft-voting blend) and picking by macro F1 directly targets
  the "Best average F1" and "Best peak F1" prizes.
- Because the *same* Stage 1 feature representation is reused for Amsterdam
  transfer, a model that fits Madrid well without overfitting city-specific
  quirks (shallow trees, moderate regularisation, no leaf-level memorisation)
  is more likely to also win the "Best low-data F1" prize. Extremely deep,
  unregularised trees (as in the baseline `RandomForestClassifier` with no
  `max_depth`) memorise Madrid and generalise worse.

This script assumes `X_madrid`, `y_madrid` are already built (e.g. from
Notebook 3's preprocessed_data.pkl, optionally merged with
`feature_engineering_extra.build_extended_features`).

Usage:
    from scripts.train_stage1 import cross_validate_candidates, fit_final_model
    results = cross_validate_candidates(X_madrid, y_madrid, n_folds=5, n_repeats=5)
    best_name = max(results, key=lambda k: results[k]["mean_f1"])
    final_model = fit_final_model(X_madrid, y_madrid, best_name)
"""

from __future__ import annotations

import numpy as np
from sklearn.ensemble import (
    HistGradientBoostingClassifier,
    RandomForestClassifier,
    VotingClassifier,
)
from sklearn.metrics import confusion_matrix, f1_score
from sklearn.model_selection import RepeatedStratifiedKFold

RANDOM_STATE = 42


def _make_candidates() -> dict:
    """Model zoo. Keep every model reasonably regularised (see module docstring)."""
    rf = RandomForestClassifier(
        n_estimators=500,
        max_depth=14,          # capped, unlike the unbounded baseline
        min_samples_leaf=5,
        class_weight="balanced",
        random_state=RANDOM_STATE,
        n_jobs=-1,
    )
    hgb = HistGradientBoostingClassifier(
        max_depth=6,
        learning_rate=0.06,
        max_iter=400,
        l2_regularization=1.0,
        class_weight="balanced",
        random_state=RANDOM_STATE,
    )
    blend = VotingClassifier(
        estimators=[("rf", rf), ("hgb", hgb)],
        voting="soft",
        n_jobs=-1,
    )
    return {"random_forest": rf, "hist_gb": hgb, "rf_hgb_blend": blend}


def cross_validate_candidates(
    X: np.ndarray,
    y: np.ndarray,
    n_folds: int = 5,
    n_repeats: int = 5,
) -> dict:
    """
    Repeated stratified CV (see Notebook 4 sec. 4.3 for why repeats matter for
    a trustworthy std-dev estimate). Returns, per candidate model:
      mean_f1, std_f1, fold_f1 (list), oof_confusion (normalised, row=recall)
    """
    rskf = RepeatedStratifiedKFold(
        n_splits=n_folds, n_repeats=n_repeats, random_state=RANDOM_STATE
    )
    candidates = _make_candidates()
    results = {name: {"fold_f1": [], "oof_true": [], "oof_pred": []} for name in candidates}

    for tr_idx, val_idx in rskf.split(X, y):
        X_tr, X_val = X[tr_idx], X[val_idx]
        y_tr, y_val = y[tr_idx], y[val_idx]
        for name, model in candidates.items():
            m = model.__class__(**model.get_params()) if not hasattr(model, "estimators") else _make_candidates()[name]
            m.fit(X_tr, y_tr)
            pred = m.predict(X_val)
            results[name]["fold_f1"].append(f1_score(y_val, pred, average="macro"))
            results[name]["oof_true"].extend(y_val.tolist())
            results[name]["oof_pred"].extend(pred.tolist())

    classes = sorted(np.unique(y))
    for name, r in results.items():
        r["mean_f1"] = float(np.mean(r["fold_f1"]))
        r["std_f1"] = float(np.std(r["fold_f1"]))
        cm = confusion_matrix(r["oof_true"], r["oof_pred"], labels=classes)
        r["oof_confusion"] = (cm / cm.sum(axis=1, keepdims=True)).tolist()
        del r["oof_true"], r["oof_pred"]

    return results


def fit_final_model(X: np.ndarray, y: np.ndarray, model_name: str):
    """Fit the chosen candidate on all of Madrid. This is the Stage 1 deliverable model."""
    model = _make_candidates()[model_name]
    model.fit(X, y)
    return model


def fit_fold_ensemble(X: np.ndarray, y: np.ndarray, model_name: str, n_folds: int = 5):
    """
    Fit one model per CV fold (trained on that fold's training split) and
    return the list, to be averaged at inference time - the "ensemble the
    fold models" trick every top MapYourCity team used (1-3 MPA points,
    Sec. IX), at essentially zero extra cost since you already ran the CV.
    Use `predict_proba_ensemble` below for inference.
    """
    skf = RepeatedStratifiedKFold(n_splits=n_folds, n_repeats=1, random_state=RANDOM_STATE)
    models = []
    for tr_idx, _ in skf.split(X, y):
        m = _make_candidates()[model_name]
        m.fit(X[tr_idx], y[tr_idx])
        models.append(m)
    return models


def predict_proba_ensemble(models: list, X: np.ndarray) -> np.ndarray:
    """Soft-vote average of predict_proba across the fold-ensemble models."""
    probas = np.stack([m.predict_proba(X) for m in models])
    return probas.mean(axis=0)


class BandDropoutWrapper:
    """
    Wraps any sklearn-compatible classifier to randomly zero out a whole
    spectral band's feature columns per training row - the tabular analogue
    of MapYourCity's "randomly hide the street-view image with p=0.5" trick,
    which every top team found improved robustness to a missing/unreliable
    input by 2-3 MPA points (Sec. V-C, VI-C). Here the "modality" that might
    be unreliable is a specific Landsat band whose calibration or drift
    happens to differ between Madrid and Amsterdam; training with it
    randomly absent forces the model to spread its decision weight across
    multiple bands instead of keying on one Madrid-specific quirk.

    `band_column_groups`: dict mapping band name -> list of column indices in
    X that derive from that band (e.g. all the "Blue_*" columns from
    feature_engineering_extra.py and the baseline pipeline). Build this from
    your feature_cols list, e.g.:
        band_column_groups = {b: [i for i, c in enumerate(feature_cols) if c.startswith(b)]
                               for b in BASE_BANDS}
    """

    def __init__(self, base_estimator, band_column_groups: dict, dropout_p: float = 0.15, seed: int = RANDOM_STATE):
        self.base_estimator = base_estimator
        self.band_column_groups = band_column_groups
        self.dropout_p = dropout_p
        self.rng = np.random.default_rng(seed)
        self.classes_ = None

    def _apply_dropout(self, X: np.ndarray) -> np.ndarray:
        X_out = X.copy()
        band_names = list(self.band_column_groups)
        for row in range(X_out.shape[0]):
            for band in band_names:
                if self.rng.random() < self.dropout_p:
                    X_out[row, self.band_column_groups[band]] = 0.0
        return X_out

    def fit(self, X, y):
        X_dropped = self._apply_dropout(X)
        self.base_estimator.fit(X_dropped, y)
        self.classes_ = self.base_estimator.classes_
        return self

    def predict(self, X):
        return self.base_estimator.predict(X)  # no dropout at inference time

    def predict_proba(self, X):
        return self.base_estimator.predict_proba(X)


if __name__ == "__main__":
    print(__doc__)
