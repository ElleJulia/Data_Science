"""
Builds the two write-up deliverables required by the submission spec
(Notebook 1, sec 1.5):
  3. A PowerPoint deck with: abstract (<=150 words) on slide 1, key design
     decisions / what worked-didn't, a table of Madrid F1 + 4 Amsterdam F1s
     with error bars, and a plot of F1 (with error bars) vs log2(sample size).
  4. A written justification (<=300 words).

This script only lays out real numbers you pass in - it does not invent
scores. Compute `madrid_cv` (mean_f1, std_f1) with train_stage1.py and
`amsterdam_results` (per shot count mean/std) with transfer_stage2.py first.

Usage:
    from scripts.build_deliverables import build_pptx, check_word_limit
    build_pptx(
        out_path="submission.pptx",
        abstract="...",
        design_decisions=["...", "..."],
        madrid_cv={"mean_f1": 0.62, "std_f1": 0.01},
        amsterdam_results={5: {"mean": .3, "std": .05}, 25: {...}, ...},
    )
    check_word_limit(justification_text, limit=300)
"""

from __future__ import annotations

import io
import math

import matplotlib.pyplot as plt
from pptx import Presentation
from pptx.util import Inches, Pt


def check_word_limit(text: str, limit: int) -> tuple[bool, int]:
    n_words = len(text.split())
    return n_words <= limit, n_words


def _add_title_slide(prs, title, subtitle=""):
    layout = prs.slide_layouts[0]
    slide = prs.slides.add_slide(layout)
    slide.shapes.title.text = title
    if subtitle:
        slide.placeholders[1].text = subtitle
    return slide


def _add_bullet_slide(prs, title, bullets):
    layout = prs.slide_layouts[1]
    slide = prs.slides.add_slide(layout)
    slide.shapes.title.text = title
    body = slide.placeholders[1].text_frame
    body.clear()
    for i, b in enumerate(bullets):
        p = body.paragraphs[0] if i == 0 else body.add_paragraph()
        p.text = b
        p.level = 0
        p.font.size = Pt(18)
    return slide


def _add_abstract_slide(prs, title, abstract_text):
    ok, n_words = check_word_limit(abstract_text, 150)
    if not ok:
        raise ValueError(f"Abstract is {n_words} words; limit is 150. Trim before building the deck.")
    slide = _add_title_slide(prs, title)
    tx_box = slide.shapes.add_textbox(Inches(0.7), Inches(2.2), Inches(8.6), Inches(4.5))
    tf = tx_box.text_frame
    tf.word_wrap = True
    tf.text = abstract_text
    for para in tf.paragraphs:
        para.font.size = Pt(16)
    return slide


def _results_table_slide(prs, madrid_cv, amsterdam_results):
    layout = prs.slide_layouts[5]
    slide = prs.slides.add_slide(layout)
    slide.shapes.title.text = "Results: macro F1 (mean ± std)"

    rows = 1 + 1 + len(amsterdam_results)  # header + madrid + one row per n
    cols = 2
    left, top, width, height = Inches(1.5), Inches(1.6), Inches(7), Inches(0.5 + 0.45 * rows)
    table_shape = slide.shapes.add_table(rows, cols, left, top, width, height)
    table = table_shape.table
    table.cell(0, 0).text = "Model"
    table.cell(0, 1).text = "Macro F1 (mean ± std)"

    table.cell(1, 0).text = "Madrid (CV)"
    table.cell(1, 1).text = f"{madrid_cv['mean_f1']:.3f} ± {madrid_cv['std_f1']:.3f}"

    for i, (n_shots, stats) in enumerate(sorted(amsterdam_results.items()), start=2):
        table.cell(i, 0).text = f"Amsterdam ({n_shots} samples/class)"
        table.cell(i, 1).text = f"{stats['mean']:.3f} ± {stats['std']:.3f}"

    for row in table.rows:
        for cell in row.cells:
            for para in cell.text_frame.paragraphs:
                para.font.size = Pt(14)
    return slide


def _f1_vs_logn_plot_bytes(amsterdam_results, madrid_cv=None) -> bytes:
    ns = sorted(amsterdam_results)
    log2_ns = [math.log2(n) for n in ns]
    means = [amsterdam_results[n]["mean"] for n in ns]
    stds = [amsterdam_results[n]["std"] for n in ns]

    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.errorbar(log2_ns, means, yerr=stds, fmt="o-", capsize=4, linewidth=2, label="Amsterdam few-shot")
    if madrid_cv is not None:
        ax.axhline(madrid_cv["mean_f1"], linestyle="--", color="green", label="Madrid CV")
    ax.set_xlabel("log2(labeled Amsterdam samples per class)")
    ax.set_ylabel("Macro F1")
    ax.set_title("Amsterdam macro F1 vs. label budget")
    ax.set_xticks(log2_ns)
    ax.set_xticklabels([str(n) for n in ns])
    ax.legend()
    fig.tight_layout()

    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150)
    plt.close(fig)
    buf.seek(0)
    return buf


def _plot_slide(prs, amsterdam_results, madrid_cv=None):
    layout = prs.slide_layouts[5]
    slide = prs.slides.add_slide(layout)
    slide.shapes.title.text = "F1 vs. log2(sample size)"
    img_bytes = _f1_vs_logn_plot_bytes(amsterdam_results, madrid_cv)
    slide.shapes.add_picture(img_bytes, Inches(1.2), Inches(1.5), width=Inches(7.5))
    return slide


def build_pptx(
    out_path: str,
    abstract: str,
    design_decisions: list[str],
    madrid_cv: dict,
    amsterdam_results: dict,
    title: str = "Building Age Classification: Cross-City Transfer",
):
    """
    madrid_cv: {"mean_f1": float, "std_f1": float}
    amsterdam_results: {n_shots: {"mean": float, "std": float}, ...}
    """
    prs = Presentation()
    _add_abstract_slide(prs, title, abstract)
    _add_bullet_slide(prs, "Key design decisions", design_decisions)
    _results_table_slide(prs, madrid_cv, amsterdam_results)
    _plot_slide(prs, amsterdam_results, madrid_cv)
    prs.save(out_path)
    return out_path


# ---------------------------------------------------------------------------
# Metric-learning submission pack
# ---------------------------------------------------------------------------


def _best_head_per_n(per_head_results: dict) -> dict:
    """
    per_head_results: {head_name: {n_shots: {"mean", "std"}, ...}, ...}
    Returns {n_shots: {"mean", "std", "head"}} using the best-scoring head
    at each shot count. This is the fair "system" view - at deployment you'd
    pick the head that works best for the n available to you.
    """
    ns = sorted(next(iter(per_head_results.values())).keys(), key=int)
    out = {}
    for n in ns:
        best_h, best = None, None
        for h, per in per_head_results.items():
            v = per[n]
            if best is None or v["mean"] > best["mean"]:
                best_h, best = h, v
        out[int(n)] = {"mean": best["mean"], "std": best["std"], "head": best_h}
    return out


def _per_head_plot_bytes(per_head_results: dict, madrid_cv=None,
                          highlight: str | None = None) -> bytes:
    """One line per head + a horizontal line for Madrid CV, error bars from std."""
    heads = list(per_head_results.keys())
    ns_str = sorted(next(iter(per_head_results.values())).keys(), key=int)
    ns = [int(n) for n in ns_str]
    log2_ns = [math.log2(n) for n in ns]

    fig, ax = plt.subplots(figsize=(8, 5))
    for h in heads:
        means = [per_head_results[h][n]["mean"] for n in ns_str]
        stds  = [per_head_results[h][n]["std"]  for n in ns_str]
        lw = 2.5 if h == highlight else 1.0
        alpha = 1.0 if h == highlight else 0.6
        ax.errorbar(log2_ns, means, yerr=stds, fmt="o-",
                    capsize=3, linewidth=lw, alpha=alpha, label=h)
    if madrid_cv is not None:
        ax.axhline(madrid_cv["mean_f1"], linestyle="--", color="green",
                   label=f"Madrid CV = {madrid_cv['mean_f1']:.3f}")
    ax.set_xlabel("log2(labeled Amsterdam samples per class)")
    ax.set_ylabel("Macro F1")
    ax.set_title("Amsterdam macro F1 vs. label budget (per head)")
    ax.set_xticks(log2_ns)
    ax.set_xticklabels([str(n) for n in ns])
    ax.grid(True, alpha=0.3)
    ax.legend(loc="lower right", fontsize=9)
    fig.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150)
    plt.close(fig)
    buf.seek(0)
    return buf


def _best_per_n_plot_bytes(best_per_n: dict, madrid_cv=None) -> bytes:
    ns = sorted(best_per_n.keys())
    log2_ns = [math.log2(n) for n in ns]
    means = [best_per_n[n]["mean"] for n in ns]
    stds  = [best_per_n[n]["std"]  for n in ns]

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.errorbar(log2_ns, means, yerr=stds, fmt="o-", capsize=5, linewidth=2.5,
                color="tab:blue", label="best head per n")
    for x, m, n in zip(log2_ns, means, ns):
        ax.annotate(best_per_n[n]["head"], (x, m),
                    textcoords="offset points", xytext=(0, 10),
                    fontsize=9, ha="center", color="tab:blue")
    if madrid_cv is not None:
        ax.axhline(madrid_cv["mean_f1"], linestyle="--", color="green",
                   label=f"Madrid CV = {madrid_cv['mean_f1']:.3f}")
    ax.set_xlabel("log2(labeled Amsterdam samples per class)")
    ax.set_ylabel("Macro F1")
    ax.set_title("Amsterdam macro F1 vs. label budget")
    ax.set_xticks(log2_ns)
    ax.set_xticklabels([str(n) for n in ns])
    ax.grid(True, alpha=0.3)
    ax.legend(loc="lower right")
    fig.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150)
    plt.close(fig)
    buf.seek(0)
    return buf


def _confusion_slide(prs, cm: list[list[float]], labels: list[int]):
    layout = prs.slide_layouts[5]
    slide = prs.slides.add_slide(layout)
    slide.shapes.title.text = "Madrid CV confusion matrix (row-normalised)"

    fig, ax = plt.subplots(figsize=(6, 5))
    import numpy as _np
    arr = _np.array(cm)
    im = ax.imshow(arr, cmap="Blues", vmin=0, vmax=1)
    ax.set_xticks(range(len(labels)))
    ax.set_yticks(range(len(labels)))
    ax.set_xticklabels(labels)
    ax.set_yticklabels(labels)
    ax.set_xlabel("Predicted class")
    ax.set_ylabel("True class")
    for i in range(len(labels)):
        for j in range(len(labels)):
            ax.text(j, i, f"{arr[i,j]:.2f}", ha="center", va="center",
                    color="white" if arr[i,j] > 0.5 else "black", fontsize=11)
    fig.colorbar(im, ax=ax)
    fig.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150)
    plt.close(fig)
    buf.seek(0)
    slide.shapes.add_picture(buf, Inches(1.7), Inches(1.3), width=Inches(6.5))
    return slide


def build_metric_pptx(
    out_path: str,
    abstract: str,
    design_decisions: list[str],
    madrid_cv: dict,
    per_head_results: dict,
    zero_shot_f1: float,
    title: str = "Metric-Learning for Cross-City Building-Age Classification",
):
    """
    Full submission deck for the metric-learning approach.

    Layout:
      1. Abstract (<=150 words)
      2. Approach at a glance (bullets)
      3. Key design decisions / what worked / what did not
      4. Results table: Madrid CV + Amsterdam per-n (best head + std)
      5. F1 vs. log2(n) plot (per head, best highlighted)
      6. F1 vs. log2(n) plot (best head per n, annotated)
      7. Madrid CV confusion matrix
    """
    prs = Presentation()
    _add_abstract_slide(prs, title, abstract)

    approach = [
        "Stage 1 (Madrid): triplet-loss embedding trained on 176 hand-engineered spectral+temporal features",
        "Cross-domain: joint StandardScaler on Madrid + Amsterdam features + CORAL alignment on pre-norm activations",
        "Loss = ordinal-weighted batch-hard triplet + cross-entropy on auxiliary softmax head + CORAL",
        "Ensemble of 3 embeddings (different seeds), L2-normalised concatenation",
        "Stage 2 (Amsterdam): six few-shot heads compared per n; best head selected per shot count",
        f"Zero-shot Amsterdam F1 (no Amsterdam labels): {zero_shot_f1:.3f}",
    ]
    _add_bullet_slide(prs, "Approach at a glance", approach)
    _add_bullet_slide(prs, "Key design decisions", design_decisions)

    # Results table: use best head per n
    best_per_n = _best_head_per_n(per_head_results)
    _metric_results_table_slide(prs, madrid_cv, best_per_n)

    # Per-head plot
    layout = prs.slide_layouts[5]
    s = prs.slides.add_slide(layout)
    s.shapes.title.text = "F1 vs. log2(n): all heads"
    highlight = _best_avg_head(per_head_results)
    s.shapes.add_picture(_per_head_plot_bytes(per_head_results, madrid_cv, highlight),
                         Inches(1.0), Inches(1.4), width=Inches(8))

    # Best-head-per-n plot
    s = prs.slides.add_slide(layout)
    s.shapes.title.text = "F1 vs. log2(n): best head at each budget"
    s.shapes.add_picture(_best_per_n_plot_bytes(best_per_n, madrid_cv),
                         Inches(1.0), Inches(1.4), width=Inches(8))

    # Confusion matrix
    if "confusion_matrix" in madrid_cv and "confusion_labels" in madrid_cv:
        _confusion_slide(prs, madrid_cv["confusion_matrix"],
                         madrid_cv["confusion_labels"])

    prs.save(out_path)
    return out_path


def _metric_results_table_slide(prs, madrid_cv, best_per_n):
    layout = prs.slide_layouts[5]
    slide = prs.slides.add_slide(layout)
    slide.shapes.title.text = "Results: macro F1 (mean ± std)"

    ns = sorted(best_per_n.keys())
    rows = 1 + 1 + len(ns)
    cols = 3
    left, top, width, height = Inches(1.0), Inches(1.5), Inches(8), Inches(0.5 + 0.45 * rows)
    table_shape = slide.shapes.add_table(rows, cols, left, top, width, height)
    table = table_shape.table
    for j, h in enumerate(["Setting", "Macro F1 (mean ± std)", "Head used"]):
        table.cell(0, j).text = h

    table.cell(1, 0).text = "Madrid (5-fold × 2-repeat CV)"
    table.cell(1, 1).text = f"{madrid_cv['mean_f1']:.3f} ± {madrid_cv['std_f1']:.3f}"
    table.cell(1, 2).text = "prototype (embedding)"

    for i, n in enumerate(ns, start=2):
        v = best_per_n[n]
        table.cell(i, 0).text = f"Amsterdam ({n} labels/class)"
        table.cell(i, 1).text = f"{v['mean']:.3f} ± {v['std']:.3f}"
        table.cell(i, 2).text = v["head"]

    for row in table.rows:
        for cell in row.cells:
            for para in cell.text_frame.paragraphs:
                para.font.size = Pt(13)
    return slide


def _best_avg_head(per_head_results: dict) -> str:
    avgs = {h: sum(v["mean"] for v in per.values()) / len(per)
            for h, per in per_head_results.items()}
    return max(avgs, key=avgs.get)


def write_justification(path: str, text: str, limit: int = 300):
    """Word-limit-checked writer for the 300-word justification (deliverable 4)."""
    ok, n_words = check_word_limit(text, limit)
    if not ok:
        raise ValueError(f"Justification is {n_words} words; limit is {limit}.")
    with open(path, "w") as f:
        f.write(text)
    return path, n_words


if __name__ == "__main__":
    print(__doc__)
